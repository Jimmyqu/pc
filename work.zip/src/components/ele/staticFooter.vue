<template>
    <div class="fixed-footer">
      <div class="lmy_bottom_div">
        <div class="w1200 lmy_bottom_box">
          <p>Copyright © 2001-2019 湖北荆楚网络科技股份有限公司 All Rights Reserved</p>
          <p class="cWhite"><a ignoreapd="1" target="_blank" href="//www.cnhubei.com/about/">营业执照</a> － <a ignoreapd="1" target="_blank" href="//www.cnhubei.com/about/">增值电信业务许可证</a> － <!--<a href=//www.cnhubei.com/gg/website/jczxqyfl20031205.htm target=_blank ignoreapd=1 class=cWhite>广告经营许可证</a> － --><a ignoreapd="1" target="_blank" href="//www.cnhubei.com/about/">互联网出版机构</a> － <a ignoreapd="1" target="_blank" href="//www.cnhubei.com/about/">网络视听节目许可证</a> － <a ignoreapd="1" target="_blank" href="//www.cnhubei.com/about/">广播电视节目许可证</a></p>

          <p class="cWhite"><a ignoreapd="1" target="_blank" href="//www.cnhubei.com/about/">关于我们</a> - <a ignoreapd="1" target="_blank" href="//www.cnhubei.com/about/">版权声明</a> - <a target="_blank" ignoreapd="1" style="color:#F00" href="//www.cnhubei.com/2018ggfw/ggfw_sy.html">广告服务</a> － <a ignoreapd="1" target="_blank" href="http://authors.cnhubei.com/">在线投稿</a></p>
          <p>版权为 荆楚网 www.cnhubei.com 所有 未经同意不得复制或镜像 </p>

        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "staticFooter"
    }
</script>

<style scoped>

  .lmy_bottom_div{ padding:0 0 30px 0; overflow:hidden; background:#226aa5;}
  .lmy_bottom_div .lmy_bottom_box{ position:relative; overflow:hidden; padding-top:30px; text-align:center}
  .lmy_bottom_div  .lmy_bottom_box p{ color:#FFF; line-height:32px;}
  .lmy_bottom_div  .lmy_bottom_box p a{
    text-decoration: none;
    color:#FFF;
  }
</style>
